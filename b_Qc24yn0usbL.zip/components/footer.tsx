export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12 mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4">EducaHub</h3>
            <p className="text-sm opacity-90">
              Transformando la educación a través de programas innovadores y de excelencia.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Navegación</h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li><a href="/" className="hover:opacity-100">Inicio</a></li>
              <li><a href="/cursos" className="hover:opacity-100">Cursos</a></li>
              <li><a href="/eventos" className="hover:opacity-100">Eventos</a></li>
              <li><a href="/about" className="hover:opacity-100">Acerca de</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Contacto</h4>
            <ul className="space-y-2 text-sm opacity-90">
              <li>Email: info@educahub.edu</li>
              <li>Teléfono: +34 91 123 45 67</li>
              <li>Ubicación: Madrid, España</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Síguenos</h4>
            <div className="flex gap-4 text-sm opacity-90">
              <a href="#" className="hover:opacity-100">Twitter</a>
              <a href="#" className="hover:opacity-100">LinkedIn</a>
              <a href="#" className="hover:opacity-100">Facebook</a>
            </div>
          </div>
        </div>
        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-75">
          <p>&copy; 2026 EducaHub. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
