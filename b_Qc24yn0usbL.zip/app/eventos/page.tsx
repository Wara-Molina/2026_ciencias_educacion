'use client'

import { Calendar, MapPin, Users } from 'lucide-react'

const events = [
  {
    id: 1,
    title: "Conferencia: El Futuro de la Educación Digital",
    description: "Únete a expertos internacionales que compartirán tendencias y oportunidades en educación digital.",
    date: "2026-04-22",
    time: "14:00",
    location: "Auditorio Principal",
    attendees: 240,
    type: "Conferencia"
  },
  {
    id: 2,
    title: "Taller: Integración de IA en el Aula",
    description: "Aprende cómo implementar herramientas de inteligencia artificial para mejorar la enseñanza.",
    date: "2026-04-25",
    time: "10:00",
    location: "Sala de Innovación",
    attendees: 45,
    type: "Taller"
  },
  {
    id: 3,
    title: "Seminario: Educación Inclusiva y Diversidad",
    description: "Discusión profunda sobre estrategias para crear espacios educativos verdaderamente inclusivos.",
    date: "2026-04-28",
    time: "15:30",
    location: "Sala de Conferencias",
    attendees: 120,
    type: "Seminario"
  },
  {
    id: 4,
    title: "Networking: Docentes y Profesionales Educativos",
    description: "Oportunidad de conectar con colegas, compartir experiencias y crear colaboraciones.",
    date: "2026-05-02",
    time: "18:00",
    location: "Terraza del Campus",
    attendees: 180,
    type: "Networking"
  },
  {
    id: 5,
    title: "Workshop: Diseño de Currículum Moderno",
    description: "Metodología práctica para diseñar currículum alineados con competencias del siglo XXI.",
    date: "2026-05-05",
    time: "09:00",
    location: "Laboratorio de Educación",
    attendees: 60,
    type: "Workshop"
  },
  {
    id: 6,
    title: "Panel: Desafíos de la Educación Actual",
    description: "Panel de rectores y directores educativos discutiendo los principales desafíos actuales.",
    date: "2026-05-08",
    time: "16:00",
    location: "Anfiteatro",
    attendees: 300,
    type: "Panel"
  },
]

function getTypeColor(type: string) {
  const colors: Record<string, string> = {
    "Conferencia": "bg-primary/10 text-primary",
    "Taller": "bg-accent/10 text-accent",
    "Seminario": "bg-secondary/10 text-secondary",
    "Networking": "bg-primary/10 text-primary",
    "Workshop": "bg-accent/10 text-accent",
    "Panel": "bg-secondary/10 text-secondary"
  }
  return colors[type] || colors.Conferencia
}

function formatDate(dateString: string) {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(date)
}

export default function Eventos() {
  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="bg-gradient-to-b from-accent/10 to-background py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Próximos Eventos</h1>
          <p className="text-lg text-muted-foreground">
            Participa en conferencias, talleres y eventos de networking con la comunidad educativa
          </p>
        </div>
      </section>

      {/* Events List */}
      <section className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-6">
            {events.map((event) => (
              <div
                key={event.id}
                className="bg-card rounded-xl border border-border p-6 hover:shadow-lg transition-shadow group cursor-pointer"
              >
                <div className="flex flex-col md:flex-row md:items-start gap-6">
                  {/* Date Box */}
                  <div className="flex-shrink-0">
                    <div className="bg-primary/10 rounded-lg p-4 text-center w-20">
                      <div className="text-xs uppercase text-muted-foreground font-semibold">
                        {new Date(event.date).toLocaleDateString('es-ES', { month: 'short' })}
                      </div>
                      <div className="text-2xl font-bold text-primary">
                        {new Date(event.date).getDate()}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(event.date).getFullYear()}
                      </div>
                    </div>
                  </div>

                  {/* Event Info */}
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-3">
                      <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                        {event.title}
                      </h3>
                      <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold w-fit ${getTypeColor(event.type)}`}>
                        {event.type}
                      </div>
                    </div>

                    <p className="text-muted-foreground mb-4">{event.description}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4 text-primary" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4 text-primary" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Users className="w-4 h-4 text-primary" />
                        <span>{event.attendees} asistentes confirmados</span>
                      </div>
                    </div>
                  </div>

                  {/* Button */}
                  <div className="flex-shrink-0">
                    <button className="w-full md:w-auto px-6 py-2 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-accent transition-colors">
                      Registrarse
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* View More */}
          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">¿Quieres ver más eventos?</p>
            <button className="px-8 py-3 border border-primary text-primary rounded-lg font-semibold hover:bg-primary/10 transition-colors">
              Ver Calendario Completo
            </button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">No te pierdas ningún evento</h2>
          <p className="text-lg opacity-90 mb-8">Suscríbete a nuestro boletín para recibir notificaciones de nuevos eventos</p>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="Tu correo electrónico"
              className="flex-1 px-4 py-3 rounded-lg bg-primary-foreground text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <button className="px-6 py-3 bg-accent text-primary rounded-lg font-semibold hover:opacity-90 transition-opacity">
              Suscribirse
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
