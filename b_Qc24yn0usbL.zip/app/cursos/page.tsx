'use client'

import { Clock, Users, BookOpen } from 'lucide-react'

const courses = [
  {
    id: 1,
    title: "Fundamentos de la Educación",
    description: "Introducción a los conceptos básicos de la pedagogía moderna y teorías educativas.",
    duration: "8 semanas",
    students: 145,
    level: "Principiante",
    instructor: "Dra. María García",
    color: "primary"
  },
  {
    id: 2,
    title: "Didáctica y Metodología",
    description: "Técnicas avanzadas para la enseñanza efectiva y planificación curricular.",
    duration: "10 semanas",
    students: 98,
    level: "Intermedio",
    instructor: "Prof. Juan López",
    color: "accent"
  },
  {
    id: 3,
    title: "Educación Inclusiva",
    description: "Estrategias para crear entornos educativos accesibles para todos los estudiantes.",
    duration: "6 semanas",
    students: 112,
    level: "Intermedio",
    instructor: "Dra. Laura Rodríguez",
    color: "secondary"
  },
  {
    id: 4,
    title: "Tecnología en la Educación",
    description: "Integración de herramientas digitales y plataformas e-learning en el aula.",
    duration: "8 semanas",
    students: 156,
    level: "Avanzado",
    instructor: "Ing. Carlos Martínez",
    color: "primary"
  },
  {
    id: 5,
    title: "Evaluación Educativa",
    description: "Métodos y técnicas para evaluar el aprendizaje de forma integral y equitativa.",
    duration: "7 semanas",
    students: 87,
    level: "Intermedio",
    instructor: "Prof. Elena Sánchez",
    color: "accent"
  },
  {
    id: 6,
    title: "Liderazgo Educativo",
    description: "Desarrollo de habilidades de gestión y liderazgo en instituciones educativas.",
    duration: "12 semanas",
    students: 65,
    level: "Avanzado",
    instructor: "Dr. Roberto Díaz",
    color: "secondary"
  },
]

function getColorClasses(color: string) {
  const colors: Record<string, { bg: string; border: string; text: string }> = {
    primary: {
      bg: "bg-primary/10",
      border: "border-primary/30",
      text: "text-primary"
    },
    accent: {
      bg: "bg-accent/10",
      border: "border-accent/30",
      text: "text-accent"
    },
    secondary: {
      bg: "bg-secondary/10",
      border: "border-secondary/30",
      text: "text-secondary"
    }
  }
  return colors[color] || colors.primary
}

export default function Cursos() {
  return (
    <div className="flex flex-col">
      {/* Header */}
      <section className="bg-gradient-to-b from-primary/10 to-background py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Nuestros Cursos</h1>
          <p className="text-lg text-muted-foreground">
            Explora nuestra amplia oferta de programas académicos diseñados para tu desarrollo profesional
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="bg-background border-b border-border py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-accent transition-colors">
              Todos los Cursos
            </button>
            <button className="px-6 py-2 bg-muted text-foreground rounded-lg font-medium hover:bg-primary/10 transition-colors">
              Principiante
            </button>
            <button className="px-6 py-2 bg-muted text-foreground rounded-lg font-medium hover:bg-primary/10 transition-colors">
              Intermedio
            </button>
            <button className="px-6 py-2 bg-muted text-foreground rounded-lg font-medium hover:bg-primary/10 transition-colors">
              Avanzado
            </button>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => {
              const colors = getColorClasses(course.color)
              return (
                <div
                  key={course.id}
                  className={`p-6 bg-card rounded-xl border border-border hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group`}
                >
                  <div className={`p-3 ${colors.bg} rounded-lg inline-block mb-4 group-hover:scale-110 transition-transform`}>
                    <BookOpen className={`w-6 h-6 ${colors.text}`} />
                  </div>

                  <div className={`inline-block px-3 py-1 ${colors.bg} rounded-full text-xs font-semibold ${colors.text} mb-4`}>
                    {course.level}
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-2">{course.title}</h3>
                  <p className="text-muted-foreground text-sm mb-6">{course.description}</p>

                  <div className="space-y-3 pt-6 border-t border-border">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Users className="w-4 h-4" />
                      <span>{course.students} estudiantes inscritos</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Instructor:</span> {course.instructor}
                    </div>
                  </div>

                  <button className={`w-full mt-6 px-4 py-2 ${colors.bg} ${colors.text} rounded-lg font-semibold hover:opacity-80 transition-opacity`}>
                    Ver Detalles
                  </button>
                </div>
              )
            })}
          </div>
        </div>
      </section>
    </div>
  )
}
