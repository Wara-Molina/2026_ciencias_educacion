'use client'

import { ArrowRight, Zap, Users, Target } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 to-background py-20 md:py-32">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-accent/20 rounded-full mb-6">
                <span className="text-sm font-semibold text-primary">Bienvenido a EducaHub</span>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6 text-foreground">
                Transformamos la <span className="text-primary">Educación</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Descubre programas académicos innovadores en Ciencias de la Educación. Formamos profesionales comprometidos con la excelencia educativa.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/cursos"
                  className="inline-flex items-center justify-center px-8 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-accent transition-colors gap-2"
                >
                  Explorar Cursos
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/about"
                  className="inline-flex items-center justify-center px-8 py-3 bg-secondary/20 text-foreground font-semibold rounded-lg hover:bg-secondary/30 transition-colors"
                >
                  Conoce Más
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-3xl"></div>
              <div className="relative bg-card rounded-2xl p-8 border border-border shadow-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 bg-primary/10 rounded-lg border border-primary/20">
                    <div className="text-3xl font-bold text-primary mb-2">500+</div>
                    <p className="text-sm text-muted-foreground">Estudiantes Activos</p>
                  </div>
                  <div className="p-6 bg-accent/10 rounded-lg border border-accent/20">
                    <div className="text-3xl font-bold text-accent mb-2">50+</div>
                    <p className="text-sm text-muted-foreground">Cursos Disponibles</p>
                  </div>
                  <div className="p-6 bg-secondary/10 rounded-lg border border-secondary/20">
                    <div className="text-3xl font-bold text-secondary mb-2">25+</div>
                    <p className="text-sm text-muted-foreground">Docentes Expertos</p>
                  </div>
                  <div className="p-6 bg-primary/10 rounded-lg border border-primary/20">
                    <div className="text-3xl font-bold text-primary mb-2">30</div>
                    <p className="text-sm text-muted-foreground">Años de Trayectoria</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">¿Por qué elegir EducaHub?</h2>
            <p className="text-lg text-muted-foreground">Ofrecemos educación de calidad con un enfoque integral</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 bg-card rounded-xl border border-border hover:shadow-lg transition-shadow">
              <div className="p-4 bg-primary/10 rounded-lg inline-block mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Educación Innovadora</h3>
              <p className="text-muted-foreground">
                Metodologías modernas que preparan a los estudiantes para los desafíos del siglo XXI.
              </p>
            </div>

            <div className="p-8 bg-card rounded-xl border border-border hover:shadow-lg transition-shadow">
              <div className="p-4 bg-accent/10 rounded-lg inline-block mb-4">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Comunidad Activa</h3>
              <p className="text-muted-foreground">
                Conexión con profesionales, docentes y estudiantes de toda la región.
              </p>
            </div>

            <div className="p-8 bg-card rounded-xl border border-border hover:shadow-lg transition-shadow">
              <div className="p-4 bg-secondary/10 rounded-lg inline-block mb-4">
                <Target className="w-6 h-6 text-secondary" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Éxito Garantizado</h3>
              <p className="text-muted-foreground">
                95% de nuestros egresados encuentran empleo en su área dentro de 6 meses.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">¿Listo para transformar tu futuro?</h2>
          <p className="text-lg opacity-90 mb-8">Únete a EducaHub y sé parte de una comunidad global de educadores</p>
          <Link
            href="/cursos"
            className="inline-flex items-center px-8 py-3 bg-primary-foreground text-primary font-semibold rounded-lg hover:bg-opacity-90 transition-all gap-2"
          >
            Comienza Ahora
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  )
}
